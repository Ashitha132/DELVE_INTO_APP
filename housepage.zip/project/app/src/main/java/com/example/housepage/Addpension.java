package com.example.housepage;

public class Addpension {
    String pensionvalue,pensionername,pensionname;

    public Addpension() {
    }

    public Addpension(String pensionvalue, String pensionername, String pensionname) {
        this.pensionvalue = pensionvalue;
        this.pensionername = pensionername;
        this.pensionname = pensionname;
    }

    public String getPensionvalue() {
        return pensionvalue;
    }

    public void setPensionvalue(String pensionvalue) {
        this.pensionvalue = pensionvalue;
    }

    public String getPensionername() {
        return pensionername;
    }

    public void setPensionername(String pensionername) {
        this.pensionername = pensionername;
    }

    public String getPensionname() {
        return pensionname;
    }

    public void setPensionname(String pensionname) {
        this.pensionname = pensionname;
    }
}
